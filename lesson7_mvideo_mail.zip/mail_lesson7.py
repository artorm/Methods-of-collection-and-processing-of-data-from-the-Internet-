from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
from selenium.webdriver.common.action_chains import ActionChains

from pymongo import MongoClient
client = MongoClient('localhost', 27017)
db = client['Mail_post']
mail_post = db.mail_post

driver = webdriver.Chrome()

driver.get('https://mail.ru/')
assert "Mail.ru: почта, поиск в интернете, новости, игры" in driver.title


elem = driver.find_element_by_id('mailbox:login')
elem.send_keys('study.ai_172')
elem.send_keys(Keys.RETURN)

elem = driver.find_element_by_id('mailbox:password')
elem.send_keys('NewPassword172')
elem.send_keys(Keys.RETURN)


time.sleep(15)
xpath = "//div[@class='dataset__items']/a[@href]"
driver.find_element_by_xpath(xpath).click()
while True:
    time.sleep(15)
    theme = driver.find_element_by_xpath("//h2[@class]").text
    data = driver.find_element_by_xpath("//div[@class='letter__author']/div[@class='letter__date']").text
    who = driver.find_element_by_xpath("//div[@class='letter__author']/span[@class='letter-contact']").text
    #body = driver.find_element_by_xpath("//tbody/tr[@align='left']/td[@style]").text
    action = ActionChains(driver)
    action.key_down(Keys.CONTROL).send_keys(Keys.ARROW_DOWN).key_up(Keys.CONTROL).perform()
    mail_post.insert_one({'theme': theme, 'data': data, 'who': who})

driver.close()
