from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
import json
chrome_options = Options()
chrome_options.add_argument('--headless')

import time
driver = webdriver.Chrome()
driver.maximize_window()
driver.get('https://www.mvideo.ru')


from pymongo import MongoClient
client = MongoClient('localhost', 27017)
db = client['MV_top']
mv = db.mv



def Mongo_data(list):
   item ={}
   item['Category'] = json.loads(list.get_attribute('data-product-info'))['productCategoryName']
   item['Vendor'] = json.loads(list.get_attribute('data-product-info'))['productVendorName']
   item['Name'] = json.loads(list.get_attribute('data-product-info'))['productName']
   item['Price'] = json.loads(list.get_attribute('data-product-info'))['productPriceLocal']
   mv.insert_one(item)
   return

top_list = WebDriverWait(driver, 60).until(EC.presence_of_element_located((By.CSS_SELECTOR, 'div.sel-hits-block')))
top_list = driver.find_element_by_css_selector('div.sel-hits-block')
top_names = top_list.find_elements_by_css_selector('a.sel-product-tile-title')
#top_names = top_list.find_elements_by_xpath("//a[@class='sel-product-tile-title']")
#button = top_list.driver.find_element_by_xpath("//a[@class='next-btn sel-hits-button-next'")

button = top_list.find_element_by_css_selector('a.sel-product-tile-title')

while button:
   if button.get_attribute("class") == 'next-btn sel-hits-button-next':
      for i in top_names:
         Mongo_data(i)
      break
   else:
      for i in top_names:
         Mongo_data(i)
      button.click()
      time.sleep(7)
      top_list = driver.find_element_by_css_selector('div.sel-hits-block')
      button = top_list.find_element_by_css_selector('a.sel-product-tile-title')
      top_names = top_list.find_elements_by_css_selector('a.sel-product-tile-title')

driver.close()

