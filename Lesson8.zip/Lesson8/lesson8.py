import pandas as pd
import matplotlib.pyplot as plt


plt.style.use('ggplot')
plt.rcParams['figure.figsize'] = (15, 5)

df = pd.read_csv('opendata.csv',
                       sep=',', encoding='Windows 1251',
                       parse_dates=['date'], dayfirst=True,
                       index_col='date')

filtered_name = df[df.name == 'Средние расходы по картам']
filtered_region = filtered_name[filtered_name.region == 'Нижегородская область']
print(filtered_region[:3])
filtered_region['value'].plot()
plt.show()
